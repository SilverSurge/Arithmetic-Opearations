#include "Division.hpp"



vector<int> Division::division(vector<int> a, vector<int> b, int B)// returns quotient of a/b
{
    vector<int> r;
    vector<int> q;
    int carry = 0;
    int temp;
    
    int k = a.size();
    int l = b.size();
    int d = k - l;

    for (int i = d; i >= 0; i--)
    {
        q.push_back(0);
    }
    r = a;

    r.push_back(0);

    int denom = 1;

    for (int i = k - l; i >= 0; i--)
    {
        q[i] = ((r[i + l] * B) + r[i + l - 1]) / b[l - 1];

        if (q[i] >= B)
        {
            q[i] = B - 1;
        }
        carry = 0;
        for (int j = 0; j < l; j++)
        {
            temp = r[i + j] - (q[i] * b[j]) + carry;
            carry = temp / B;
            r[i + j] = temp % B;
            if (r[i + j] < 0)
            {
                carry -= 1;
                r[i + j] += B;
            }
        }
        r[i + l] = r[i + l] + carry;
        while (r[i + l] < 0)
        {
            carry = 0;
            for (int j = 0; j < l; j++)
            {
                temp = r[i + j] + b[j] + carry;
                carry = temp / B;
                r[i + j] = temp % B;
                if (r[i + j] < 0)
                {
                    carry -= 1;
                    r[i + j] += B;
                }
            }
            r[i + l] += carry;
            q[i] -= 1;
        }
    }

    return q;
}


Division::Division(Expression* _lexp, Expression* _rexp)
{
    lexp = _lexp;
    rexp = _rexp;
}
void Division::calculate()
{
    // cout << "Addition" << endl;
    lexp->calculate();
    rexp->calculate();

    Number lnum = lexp->value;
    Number rnum = rexp->value;

    string lrep = lexp->representation;
    string rrep = rexp->representation;

    representation = "Division("+lrep+", "+rrep+")";

    // pair<vector<int>, int> results = division_real(lnum.digits, lnum.power, rnum.digits, rnum.power, 10);
    value.digits = division(lnum.digits, rnum.digits, 10);
    value.power = lnum.power - rnum.power;
    
}
