#include <bits/stdc++.h>
using namespace std;

#ifndef NUMBER_H
#define NUMBER_H

class Number
{
public:
    // attributes
    int power;
    vector<int> digits;

    // constructor
    Number(string s);
    Number(){}
    
    // to string
    string to_string();
};

#endif //NUMBER_H
