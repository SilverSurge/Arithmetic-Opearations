#include <bits/stdc++.h>
using namespace std;

#include "Expression.hpp"

#ifndef SUBTRACTION_H
#define SUBTRACTION_H

class Subtraction: public Expression
{
private:
    vector<int> pad_zeroes(vector<int> a, int n); // adds 0 at the back of the vector
    vector<int> adjustCarry(vector<int> a, int index, int B); // returns a vector after adjusting the carry
    vector<int> subtraction(vector<int> a, vector<int> b, int B); // performs subtraction of vector b and vector a in integer format
    int comparator(vector<int> a, vector<int> b); // returns 1 if a is greater than b else 0
    pair<vector<int>, int> subtraction_real(vector<int> a, int power_a, vector<int> b, int power_b, int B);//performs subtraction of two vectors in real number format in base B


public:
    // attributes
    Expression *lexp, *rexp;
    // methods
    Subtraction(Expression* _lexp, Expression* _rexp);
    virtual void calculate();
    
};

#endif // SUBTRACTION_H