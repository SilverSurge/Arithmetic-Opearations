#include <bits/stdc++.h>
using namespace std;

#include "Expression.hpp"

#ifndef MULTIPLICATION_H
#define MULTIPLICATION_H

class Multiplication: public Expression
{
private:
    vector<int> multiplication(vector<int> a, vector<int> b, int B); //function to perform multiplication of two vectors in base B
    
    pair<vector<int>, int> multiplication_real(vector<int> a, int power_a, vector<int> b, int power_b, int B);//function to perform multiplication of two vectors in real number format in base B
    

public:
    Expression *lexp, *rexp;
    Multiplication(Expression* _lexp, Expression* _rexp);
    
    virtual void calculate();
    
};

#endif // MULTIPLICATION_H