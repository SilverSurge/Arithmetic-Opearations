#include "Subtraction.hpp"

vector<int> Subtraction::pad_zeroes(vector<int> a, int n) // adds 0 at the back of the vector
{
vector<int> c;

for (int i = 0; i < n; i++)
    c.push_back(0);

for (int i = 0; i < a.size(); i++)
    c.push_back(a[i]);

return c;
}
vector<int> Subtraction::adjustCarry(vector<int> a, int index, int B) // returns a vector after adjusting the carry
{
    for (int i = index + 1; i < a.size(); i++)
    {
        if (a[i] != 0)
        {
            a[i] -= 1;
            for (int j = index + 1; j < i; j++)
            {
                a[j] += B - 1;
            }
            a[index] += B;
        }
    }

    return a;
}
vector<int> Subtraction::subtraction(vector<int> a, vector<int> b, int B) // performs subtraction of vector b and vector a in integer format
{
    
    int l1 = a.size(); // always less than or equal to l2
    int l2 = b.size();
    vector<int> c;
    // cout << l1 << "**" << l2 << endl;

    
    int carry = 0;
    if (l1 == l2)
    {
        for (int i = 0; i < l1; i++)
        {

            c.push_back((-a[i] + b[i] + carry) % B);
            carry = (-a[i] + b[i] + carry) / B;
        }

        for (int i = l1; i < l2; i++)
        {

            c.push_back((b[i] + carry) % B);

            carry = (b[i] + carry) / B;
        }

        if (carry)
            c.push_back(carry);
    }
    else
    {
        for (int i = 0; i < l1; i++)
        {
            if (a[i] < b[i])
            {
                c.push_back((-a[i] + b[i] + carry) % B);
                carry = (-a[i] + b[i] + carry) / B;
            }
            else
            {

                b = adjustCarry(b, i, B);
                c.push_back((-a[i] + b[i] + carry) % B);
                carry = (-a[i] + b[i] + carry) / B;
            }
        }
        for (int i = l1; i < l2; i++)
        {

            c.push_back((b[i] + carry) % B);
            carry = (b[i] + carry) / B;
        }

        if (carry)
            c.push_back(carry);
    }

    return c;
}
int Subtraction::comparator(vector<int> a, vector<int> b) // returns 1 if a is greater than b else 0
{
    if (a.size() > b.size())
        return 1;
    else if (a.size() < b.size())
        return 0;
    else
    {
        for (int i = a.size() - 1; i >= 0; i--)
        {
            if (a[i] > b[i])
                return 1;
            else if (a[i] < b[i])
                return 0;
        }
    }
    return 0;
}
pair<vector<int>, int> Subtraction::subtraction_real(vector<int> a, int power_a, vector<int> b, int power_b, int B)//performs subtraction of two vectors in real number format in base B
{
    
    
    int l1 = a.size();
    int l2 = b.size();
    vector<int> c; // answer
    int carry = 0;

    if (power_a < power_b)
    {
        b = pad_zeroes(b, power_b - power_a);
        power_b = power_a;
    }
    else
    {
        a = pad_zeroes(a, -power_b + power_a);
        power_a = power_b;
    }
    // cout << a.size() << endl;
    // for(const auto &ai: a)
    //     cout << ai ;
    // cout << endl;
    // while(b.size() <= a.size())
    //     b.push_back(0);
    // cout << b.size() << endl;
    // for(const auto &bi: b)
    //     cout << bi ;
    // cout << endl;
    if(!comparator(a,b))
        swap(a,b);
    c = subtraction(b, a, B);
    // for(const auto &ci: c)
    //     cout << ci;
    // cout << endl;
    return make_pair(c, power_a);
}


Subtraction::Subtraction(Expression* _lexp, Expression* _rexp)
{
    lexp = _lexp;
    rexp = _rexp;
}
    void Subtraction::calculate()
{
    // cout << "Addition" << endl;
    lexp->calculate();
    rexp->calculate();

    Number lnum = lexp->value;
    Number rnum = rexp->value;

    string lrep = lexp->representation;
    string rrep = rexp->representation;

    representation = "Subtraction("+lrep+", "+rrep+")";

    pair<vector<int>, int> results = subtraction_real(lnum.digits, lnum.power, rnum.digits, rnum.power, 10);
    value.digits = results.first;
    value.power = results.second;
    // vector implementation here
}
