#include <bits/stdc++.h>
using namespace std;

#include "Number.hpp"
#include "Expression.hpp"
#include "Constant.hpp"
#include "Addition.hpp"
#include "Subtraction.hpp"
#include "Multiplication.hpp"
#include "Division.hpp"


class Square: public Expression
{
public:
    Expression *exp;
    Square(Expression *_exp)
    {
        exp = _exp;
    }
    void calculate()
    {
        Multiplication *multiplier = new Multiplication(exp, exp);
        multiplier->calculate();
        value = multiplier->value;
    }
};

Number to_number(string s)
{

    Number res;
    vector<int> temp;

    res.digits.assign(s.size(), 0);
    res.power = 0;
    int idx = 0;
    // 1234.56
    for(int i=s.size()-1; i>=0; i--)
    {
        if(s[i] != '.')
            temp.push_back(s[i]-'0');
    }

    cout << temp.size() << endl;
    return res;
    while(temp.size() > 0 && temp.back() == 0)
    {
        temp.pop_back();
    }
    res.digits = temp;
    int pow = 0;
    for(int i=1; i<s.size(); i++)
    {
        if(s[s.size()-i] == '.')
        {
            pow = -(i-1);
            break;
        }    
    }
    res.power = pow;
    return res;
}

int main()
{
    // Number num1 = Number("2.5");
    // Expression *con1 = new Constant(num1);
    // Expression *sqr = new Square(con1);
    // sqr->calculate();
    // cout << sqr->value.to_string() << endl; 
    // cout << sqr->value.power << endl; 

    string n1,n2;
    char op;
    cout<<"Enter First number : "<<endl;
    cin>>n1;
    cout<<"Enter Second number : "<<endl;
    cin>>n2;
    cout<<"Enter Operation : "<<endl;
    cin>>op;

    bool f=true;    
    if(op!='+' && op!='-' && op!='*' && op !='/')f=false;
    int cnt1=0,cnt2=0;
    for(int i=0;i<n1.size();i++){
        if(!((n1[i]>='0' && n1[i]<='9') || (n1[i]=='.')))f=true;
        if(n1[i]=='.')cnt1++;
    }
    for(int i=0;i<n2.size();i++){
        if(!((n2[i]>='0' && n2[i]<='9') || (n2[i]=='.')))f=true;
        if(n2[i]=='.')cnt2++;
    }
    
    if((!f) || cnt1>1 || cnt2>1){
        cout<<"Invalid Input"<<endl;
    }else{
        Number num_1 = Number(n1);
        Number num_2 = Number(n2);
        
        // return 0;

        Expression *constant_1 = new Constant(num_1);
        Expression *constant_2 = new Constant(num_2);

        if(op=='+'){
            Expression *op_1 = new Addition(constant_1, constant_2);
            op_1->calculate();
            cout<<"Result : " << op_1->value.to_string() << endl;
            cout<<"Power : " << op_1->value.power << endl;
        }
        else if(op=='-'){
            Expression *op_2 = new Subtraction(constant_1, constant_2);
            op_2->calculate();
            cout<<"Result : " << op_2->value.to_string() << endl;
            cout<<"Power : " << op_2->value.power << endl;
        }
        else if(op=='*'){
            Expression *op_3 = new Multiplication(constant_1, constant_2);
            op_3->calculate();
            cout<<"Result : " << op_3->value.to_string() << endl;
            cout<<"Power : " << op_3->value.power << endl;
        }
        else if(op=='/'){
            
            bool f1=false;

            for(int i=0;i<n2.size();i++)if(n2[i]>'0' && n2[i]<='9')f1=true;
            if(!f1){
                cout<<"Divide by zero Error"<<endl;
                return 0; 
            }
            Expression *op_4 = new Division(constant_1, constant_2);
            op_4->calculate();
            cout<<"Result : " << op_4->value.to_string() << endl;
            cout<<"Power : " << op_4->value.power << endl;
        }
    }

    return 0;
}
/* 

$ g++ calculator.cpp Number.cpp Expression.hpp Constant.cpp Addition.cpp Subtraction.cpp Multiplication.cpp Division.cpp

123a + 123      --> Invalid Input
123 / 00        --> Divide by zero Error.
123.45.22 + 123 --> Invalid Input 
1230.45838683000 + 657.89 = 188834838683000, -11
1230.45838683000 - 657.89 = 057256838683000, -11
1230.45838683000 / 657.89 = 01870310214, -9
1230.45838683000 * 657.89 = 08095062681115887000, -13

*/



