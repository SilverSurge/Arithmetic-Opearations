#include <bits/stdc++.h>
using namespace std;

#include "Expression.hpp"

#ifndef ADDITION_H
#define ADDITION_H

class Addition: public Expression
{
private:
    vector<int> addition(vector<int> a, vector<int> b, int B);
    //performs the addiiton of two given vectors in base B
    vector<int> pad_zeroes(vector<int> a, int n);
    // adds 0 at the back of the vector
    pair<vector<int>, int> addition_real(vector<int> a, int power_a, vector<int> b, int power_b, int B); //function to perform addition of two vectors in real number format

public:
    Expression *lexp, *rexp;
    Addition(Expression* _lexp, Expression* _rexp);
    virtual void calculate();
};

#endif // ADDITION_H