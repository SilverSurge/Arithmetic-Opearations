#include <bits/stdc++.h>
using namespace std;

#include "Number.hpp"

#ifndef EXPRESSION_H
#define EXPRESSION_H

class Expression
{
public:
    Number value;
    string representation;

    virtual void calculate(){}
};

#endif // EXPRESSION_H