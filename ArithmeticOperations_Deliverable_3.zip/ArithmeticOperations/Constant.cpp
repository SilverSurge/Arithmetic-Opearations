#include "Constant.hpp"
    
    
Constant::Constant(Number _value)
{
    value = _value;
    representation = "Constant(";
    representation.append(value.to_string());
    representation += ")";
}