#include "Number.hpp"

Number::Number(string s)
{
    
    vector<int> temp;
    power = 0;
    int idx = 0;
    // 1234.56
    for(int i=s.size()-1; i>=0; i--)
    {
        if(s[i] != '.')
            temp.push_back(s[i]-'0');
    }

    while(temp.size() > 0 && temp.back() == 0)
    {
        temp.pop_back();
    }
    digits = temp;
    int pow = 0;
    for(int i=1; i<s.size(); i++)
    {
        if(s[s.size()-i] == '.')
        {
            pow = -(i-1);
            break;
        }    
    }
    power = pow;
}


string Number::to_string()
{
    string res;
    for (int i = digits.size() - 1; i > -1; i--)
    {
        res.push_back(digits[i]+'0');
    }

    return res;
}