#include "Multiplication.hpp"


vector<int> Multiplication::multiplication(vector<int> a, vector<int> b, int B) //function to perform multiplication of two vectors in base B
{

    int l = a.size();
    int k = b.size();
    vector<int> c;

    for (int i = 0; i < k + l; i++)
        c.push_back(0);

    int carry = 0;
    for (int i = 0; i < k; i++)
    {
        carry = 0;
        for (int j = 0; j < l; j++)
        {
            int temp = a[j] * b[i] + c[i + j] + carry;

            c[i + j] = temp % B;
            carry = temp / B;
        }

        c[i + l] = carry;
    }

    return c;
}

pair<vector<int>, int> Multiplication::multiplication_real(vector<int> a, int power_a, vector<int> b, int power_b, int B)//function to perform multiplication of two vectors in real number format in base B
{
    vector<int> c = multiplication(a, b, B);
    return make_pair(c, power_a + power_b);
}


Multiplication::Multiplication(Expression* _lexp, Expression* _rexp)
{
    lexp = _lexp;
    rexp = _rexp;
}
    void Multiplication::calculate()
{
    // cout << "Addition" << endl;
    lexp->calculate();
    rexp->calculate();

    Number lnum = lexp->value;
    Number rnum = rexp->value;

    string lrep = lexp->representation;
    string rrep = rexp->representation;

    representation = "Multiplication("+lrep+", "+rrep+")";

    pair<vector<int>, int> results = multiplication_real(lnum.digits, lnum.power, rnum.digits, rnum.power, 10);
    value.digits = results.first;
    value.power = results.second;
    // vector implementation here
}
