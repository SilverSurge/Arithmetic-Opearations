#include <bits/stdc++.h>
using namespace std;

#include "Expression.hpp"

#ifndef CONSTANT_H
#define CONSTANT_H

class Constant: public Expression
{
public:
    Constant(Number _value);

    virtual void calculate(){}
};

#endif // CONSTANT_H