#include <bits/stdc++.h>
using namespace std;

#include "Expression.hpp"

#ifndef DIVISION_H
#define DIVISION_H

class Division: public Expression
{
private:
    
    vector<int> division(vector<int> a, vector<int> b, int B);// returns quotient of a/b
    
public:
    // attributes
    Expression *lexp, *rexp;
    // methods
    Division(Expression* _lexp, Expression* _rexp);
    virtual void calculate();

};

#endif // DIVISION_H